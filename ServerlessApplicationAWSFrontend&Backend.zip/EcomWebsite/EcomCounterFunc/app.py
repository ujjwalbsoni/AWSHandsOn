import boto3                                   
import json                                   
import decimal 
dynamodb = boto3.resource('dynamodb')                         
table = dynamodb.Table('ecomvisitorcounter')
def lambda_handler(event, context):
    response = table.update_item(                                                             
        Key={
            'id':"10"
        },
        UpdateExpression="set sequence_number = sequence_number + :val",
        ExpressionAttributeValues={
            ':val':decimal.Decimal(1)
        },
        ReturnValues="UPDATED_NEW"
    )
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
			'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
		'body': json.dumps({
            'sequence_number':  str(response["Attributes"]["sequence_number"])
        })
        ,
        "isBase64Encoded": False
    }
    


